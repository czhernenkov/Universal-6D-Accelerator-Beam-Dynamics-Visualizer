# Interactive Accelerator Beam Dynamics Simulator

A self-contained browser-based accelerator physics visualization and simulation environment.

## Included experiments

- Transverse Courant–Snyder / Twiss phase-space visualization
- Longitudinal RF and z–delta dynamics
- Simplified 2 km storage-ring / dipole-lattice experiment
- Interactive particle inspection
- Configurable RF and lattice parameters
- Multi-turn tracking and beam diagnostics

## Run locally

Open `index.html` in a modern browser.

## GitHub Pages

This repository is designed to work as a static GitHub Pages site. No build system or server is required.

1. Create a GitHub repository.
2. Upload `index.html` and `README.md`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the branch containing `index.html` and the `/ (root)` folder.
6. Save and open the generated GitHub Pages URL.

## Notes

The ring model is an educational/research prototype. Its lattice, RF, and tracking models are configurable and should be validated against analytical calculations or established accelerator-physics codes before being interpreted as a high-fidelity machine model.
